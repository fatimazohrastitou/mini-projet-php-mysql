<footer  style="bottom:-500%;position:absolute;width:100%;height:-300%;" class="bo">
<div class="foot p-3 text-center bg-dark">
    <p class="para text-light">All rights reserved ©- Designed on 2023 <a href="contact.php">Contact us</a> </p>

<ul class="footer-icons">

<li><a href="#"><i class="fa-brands fa-instagram"></i></a></li>
<li><a href="#"><i class="fa-brands fa-facebook"></i></a></li>
<li><a href="#"><i class="fa-brands fa-twitter"></i></a></li>
<li><a href="#"><i class="fa-brands fa-whatsapp"></i></a></li>
</ul>
</div>
</footer>
<!--<i class="fa-brands fa-instagram"></i>
<i class="fa-brands fa-facebook"></i>
<i class="fa-brands fa-twitter"></i>
<i class="fa-brands fa-whatsapp"></i>
bottom:-300%;position:absolute;width:100%;height:-300%;-->